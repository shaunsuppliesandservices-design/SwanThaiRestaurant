import React, { useState, useRef } from 'react';
import JobApplication from './components/JobApplication';
import { 
  Menu, 
  X, 
  FileText, 
  MapPin, 
  Phone, 
  Mail, 
  Facebook, 
  Instagram, 
  Star,
  Clock,
  Users,
  ChefHat,
  ExternalLink,
  ShoppingCart,
  Smartphone,
  Plus,
  Minus,
  Sunset
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [showJobApplication, setShowJobApplication] = useState(false);
  const [hoverTimeout, setHoverTimeout] = useState<NodeJS.Timeout | null>(null);

  // Get sunset time for today
  const getSunsetTime = () => {
    // Accurate sunset times for Rancho Palos Verdes, CA based on timeanddate.com
    const now = new Date();
    const month = now.getMonth();
    const day = now.getDate();
    
    let sunsetHour, sunsetMinute;
    
    // January
    if (month === 0) {
      if (day <= 5) {
        sunsetHour = 17; sunsetMinute = 0; // ~5:00 PM
      } else if (day <= 15) {
        sunsetHour = 17; sunsetMinute = 10; // ~5:10 PM
      } else if (day <= 25) {
        sunsetHour = 17; sunsetMinute = 25; // ~5:25 PM
      } else {
        sunsetHour = 17; sunsetMinute = 40; // ~5:40 PM
      }
    }
    // February  
    else if (month === 1) {
      if (day <= 5) {
        sunsetHour = 17; sunsetMinute = 55; // ~5:55 PM
      } else if (day <= 15) {
        sunsetHour = 18; sunsetMinute = 10; // ~6:10 PM
      } else if (day <= 25) {
        sunsetHour = 18; sunsetMinute = 25; // ~6:25 PM
      } else {
        sunsetHour = 18; sunsetMinute = 35; // ~6:35 PM
      }
    }
    // March
    else if (month === 2) {
      if (day <= 5) {
        sunsetHour = 18; sunsetMinute = 45; // ~6:45 PM
      } else if (day <= 15) {
        sunsetHour = 19; sunsetMinute = 0; // ~7:00 PM (DST begins mid-March)
      } else if (day <= 25) {
        sunsetHour = 19; sunsetMinute = 15; // ~7:15 PM
      } else {
        sunsetHour = 19; sunsetMinute = 25; // ~7:25 PM
      }
    }
    // April
    else if (month === 3) {
      if (day <= 5) {
        sunsetHour = 19; sunsetMinute = 35; // ~7:35 PM
      } else if (day <= 15) {
        sunsetHour = 19; sunsetMinute = 45; // ~7:45 PM
      } else if (day <= 25) {
        sunsetHour = 19; sunsetMinute = 55; // ~7:55 PM
      } else {
        sunsetHour = 19; sunsetMinute = 30; // ~7:30 PM
      }
    }
    // May
    else if (month === 4) {
      if (day <= 5) {
        sunsetHour = 20; sunsetMinute = 0; // ~8:00 PM
      } else if (day <= 15) {
        sunsetHour = 20; sunsetMinute = 5; // ~8:05 PM
      } else if (day <= 25) {
        sunsetHour = 20; sunsetMinute = 10; // ~8:10 PM
      } else {
        sunsetHour = 20; sunsetMinute = 15; // ~8:15 PM
      }
    }
    // June
    else if (month === 5) {
      if (day <= 5) {
        sunsetHour = 20; sunsetMinute = 18; // ~8:18 PM
      } else if (day <= 15) {
        sunsetHour = 20; sunsetMinute = 20; // ~8:20 PM
      } else if (day <= 25) {
        sunsetHour = 20; sunsetMinute = 21; // ~8:21 PM (summer solstice around June 21)
      } else {
        sunsetHour = 20; sunsetMinute = 20; // ~8:20 PM
      }
    }
    // July
    else if (month === 6) {
      if (day <= 5) {
        sunsetHour = 20; sunsetMinute = 18; // ~8:18 PM
      } else if (day <= 15) {
        sunsetHour = 20; sunsetMinute = 15; // ~8:15 PM
      } else if (day <= 25) {
        sunsetHour = 20; sunsetMinute = 10; // ~8:10 PM
      } else {
        sunsetHour = 20; sunsetMinute = 5; // ~8:05 PM
      }
    }
    // August
    else if (month === 7) {
      if (day <= 5) {
        sunsetHour = 19; sunsetMinute = 58; // ~7:58 PM
      } else if (day <= 15) {
        sunsetHour = 19; sunsetMinute = 48; // ~7:48 PM
      } else if (day <= 25) {
        sunsetHour = 19; sunsetMinute = 35; // ~7:35 PM
      } else {
        sunsetHour = 19; sunsetMinute = 22; // ~7:22 PM
      }
    }
    // September
    else if (month === 8) {
      if (day <= 5) {
        sunsetHour = 19; sunsetMinute = 8; // ~7:08 PM
      } else if (day <= 15) {
        sunsetHour = 18; sunsetMinute = 52; // ~6:52 PM
      } else if (day <= 25) {
        sunsetHour = 18; sunsetMinute = 35; // ~6:35 PM
      } else {
        sunsetHour = 18; sunsetMinute = 18; // ~6:18 PM
      }
    }
    // October
    else if (month === 9) {
      if (day <= 5) {
        sunsetHour = 18; sunsetMinute = 0; // ~6:00 PM
      } else if (day <= 15) {
        sunsetHour = 17; sunsetMinute = 45; // ~5:45 PM
      } else if (day <= 25) {
        sunsetHour = 17; sunsetMinute = 30; // ~5:30 PM
      } else {
        sunsetHour = 17; sunsetMinute = 15; // ~5:15 PM
      }
    }
    // November (DST ends first Sunday)
    else if (month === 10) {
      if (day <= 5) {
        sunsetHour = 17; sunsetMinute = 0; // ~5:00 PM (before DST ends)
      } else if (day <= 15) {
        sunsetHour = 16; sunsetMinute = 50; // ~4:50 PM (after DST ends)
      } else if (day <= 25) {
        sunsetHour = 16; sunsetMinute = 40; // ~4:40 PM
      } else {
        sunsetHour = 16; sunsetMinute = 35; // ~4:35 PM
      }
    }
    // December
    else {
      if (day <= 5) {
        sunsetHour = 16; sunsetMinute = 32; // ~4:32 PM
      } else if (day <= 15) {
        sunsetHour = 16; sunsetMinute = 30; // ~4:30 PM
      } else if (day <= 25) {
        sunsetHour = 16; sunsetMinute = 32; // ~4:32 PM (winter solstice around Dec 21)
      } else {
        sunsetHour = 16; sunsetMinute = 38; // ~4:38 PM (days start getting longer)
      }
    }
    
    const sunsetTime = new Date();
    sunsetTime.setHours(sunsetHour, sunsetMinute, 0, 0);
    
    return sunsetTime.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  // Get current day and determine if open
  const getCurrentStatus = () => {
    const now = new Date();
    const day = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const hour = now.getHours();
    const minute = now.getMinutes();
    const currentTime = hour + minute / 60;
    
    // Store hours: Sun-Thu 11:30am-9:00pm, Fri-Sat 11:30am-9:30pm
    const openTime = 11.5; // 11:30am
    let closeTime;
    
    if (day === 5 || day === 6) { // Friday or Saturday
      closeTime = 21.5; // 9:30pm
    } else { // Sunday through Thursday
      closeTime = 21; // 9:00pm
    }
    
    const isOpen = currentTime >= openTime && currentTime < closeTime;
    
    return {
      isOpen,
      todayHours: day === 5 || day === 6 ? '11:30am - 9:30pm' : '11:30am - 9:00pm'
    };
  };

  const { isOpen, todayHours } = getCurrentStatus();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const handleMouseEnter = () => {
    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
      setHoverTimeout(null);
    }
    setIsMenuOpen(true);
  };

  const handleMouseLeave = () => {
    const timeout = setTimeout(() => {
      setIsMenuOpen(false);
    }, 300); // 300ms delay before closing
    setHoverTimeout(timeout);
  };
  const jobOpenings: any[] = [];

  // If showing job application, render that component
  if (showJobApplication) {
    return <JobApplication onBack={() => setShowJobApplication(false)} />;
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hours Status Bar */}
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-sm">
        <div className="bg-white text-gray-900 py-2 px-4 text-center text-sm font-medium border-b border-gray-200">
          <div className="flex items-center justify-center gap-2">
            <Clock className="h-4 w-4" />
            <span className={`inline-flex items-center gap-1 ${isOpen ? 'text-green-600' : 'text-red-600'}`}>
              {isOpen ? '● OPEN NOW' : '● CLOSED'}
            </span>
            <span className="hidden sm:inline">- Today's Hours: {todayHours}</span>
            <span className="inline-flex text-orange-600 font-medium items-center gap-1 ml-2 sm:ml-4">
              <Sunset className="h-4 w-4" />
              Today's sunset: {getSunsetTime()}
            </span>
          </div>
        </div>
        <div className="bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
            {/* Left side - Hamburger menu */}
            <div className="flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-900 hover:text-amber-600 p-3 md:hidden"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
              {/* Desktop hamburger menu - always visible */}
              <div
                className="relative hidden md:block"
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
              >
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="text-gray-900 hover:text-amber-600 px-8 py-6 transition-colors text-lg font-medium border-2 border-transparent hover:border-amber-200 rounded-lg"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
                
                {/* Hamburger Dropdown Menu - Desktop */}
                {isMenuOpen && (
                  <div className="absolute top-full left-0 w-72 bg-white border border-gray-200 rounded-lg shadow-xl z-[60] transform transition-all duration-200">
                    <div className="py-2">
                      <button onClick={() => scrollToSection('home')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">Home</button>
                      <button onClick={() => scrollToSection('order')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">Order Online</button>
                      <button onClick={() => scrollToSection('menu')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">Menu</button>
                      <button onClick={() => scrollToSection('reservations')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">Reservations</button>
                      <button onClick={() => scrollToSection('careers')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">Careers</button>
                      <button onClick={() => scrollToSection('about')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">About</button>
                      <button onClick={() => scrollToSection('contact')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors border-b border-gray-100">Contact</button>
                      <button onClick={() => scrollToSection('policies')} className="text-gray-900 hover:text-amber-600 hover:bg-amber-50 block w-full text-left px-8 py-4 text-lg font-medium transition-colors">Policies & Disclaimers</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex md:justify-center md:flex-1 md:absolute md:left-0 md:right-0">
              <div className="flex items-baseline space-x-8">
                <button onClick={() => scrollToSection('home')} className="text-gray-900 hover:text-white hover:bg-amber-600 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:shadow-lg hover:scale-105">Home</button>
                <button onClick={() => scrollToSection('order')} className="text-gray-900 hover:text-white hover:bg-amber-600 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:shadow-lg hover:scale-105">Order Online</button>
                <button onClick={() => scrollToSection('menu')} className="text-gray-900 hover:text-white hover:bg-amber-600 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:shadow-lg hover:scale-105">Menu</button>
                <button onClick={() => scrollToSection('reservations')} className="text-gray-900 hover:text-white hover:bg-amber-600 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:shadow-lg hover:scale-105">Reservations</button>
                <button onClick={() => scrollToSection('careers')} className="text-gray-900 hover:text-white hover:bg-amber-600 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:shadow-lg hover:scale-105">Careers</button>
                <button onClick={() => scrollToSection('policies')} className="text-gray-900 hover:text-white hover:bg-amber-600 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:shadow-lg hover:scale-105">Policies & Disclaimers</button>
              </div>
            </div>

            {/* Right side - placeholder for future content */}
            <div className="flex items-center">
              {/* This space can be used for additional navigation items or branding */}
            </div>
          </div>
        </div>

        </div>

        {/* Mobile menu */}
        {/* Mobile menu - separate from hamburger dropdown */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-gray-200">
              <button onClick={() => scrollToSection('home')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Home</button>
              <button onClick={() => scrollToSection('order')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Order Online</button>
              <button onClick={() => scrollToSection('menu')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Menu</button>
              <button onClick={() => scrollToSection('reservations')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Reservations</button>
              <button onClick={() => scrollToSection('careers')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Careers</button>
              <button onClick={() => scrollToSection('about')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">About</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Contact</button>
              <button onClick={() => scrollToSection('policies')} className="text-gray-900 hover:text-amber-600 block px-3 py-2 text-base font-medium transition-colors">Policies & Disclaimers</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0">
          <img 
            src="/Screenshot_20221019_161802.jpg" 
            alt="Thai cuisine and sunset dining" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 -mt-32">
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-4 tracking-wide text-amber-100 drop-shadow-2xl">
            Swan Thai, RPV
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
            
          </p>
        </div>

        {/* Social Media Float */}
        <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-40 space-y-4">
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="block p-3 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors">
            <Facebook className="h-5 w-5" />
          </a>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="block p-3 bg-pink-600 text-white rounded-full shadow-lg hover:bg-pink-700 transition-colors">
            <Instagram className="h-5 w-5" />
          </a>
          <a href="https://www.yelp.com/biz/swan-thai-rancho-palos-verdes" target="_blank" rel="noopener noreferrer" className="block p-3 bg-red-600 text-white rounded-full shadow-lg hover:bg-red-700 transition-colors">
            <Star className="h-5 w-5" />
          </a>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Swan Thai, RPV</h2>
              <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                Nestled in the heart of Rancho Palos Verdes with breathtaking sunsets and sweeping views of Catalina Island, Swan Thai RPV offers a unique dining experience. Located near scenic hiking trails and coastal vistas, it's the perfect destination for locals and visitors alike. Enjoy our full bar, vibrant ambiance, and thoughtfully crafted dishes made to satisfy both the adventurous and the classic palate.
              </p>
            </div>
            <div className="relative">
              <img 
                src="/Outdoor Dining.jpg" 
                alt="Swan Thai Outdoor Dining" 
                className="rounded-xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Order Online Section */}
      <section id="order" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Order Online</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Order for Take Out or Delivery
            </p>
            <div className="mt-8">
              <a href="https://swanthairpv.blizzfull.com/" target="_blank" rel="noopener noreferrer" className="bg-amber-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors shadow-lg inline-flex items-center gap-2">
                <ShoppingCart className="h-5 w-5" />
                Order Online
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section with PDF Upload */}
      <section id="menu" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Menus</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Click below to View & Download a PDF version of our menus
            </p>
          </div>

          {/* Menu Preview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <a href="https://drive.google.com/file/d/1DdvJbxpLHmrPx_6Y-KAO0Vo1sC5tXOCH/view?usp=drive_link" target="_blank" rel="noopener noreferrer" className="rounded-xl shadow-lg overflow-hidden group hover:shadow-xl transition-shadow block">
              <img src="/Thai Tea Boba 1.jpg" alt="Thai Tea Boba - Drinks Menu" className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
              <div className="bg-white p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-amber-600 transition-colors">Drinks, Cocktails, and Desserts</h3>
                <p className="text-gray-600">Cocktails, wines, beers, non-alcoholic beverages, and desserts</p>
              </div>
            </a>
            
            <a href="https://drive.google.com/file/d/1RMF1G3hTggBifrgY4NZf96SOL53zjB-P/view?usp=drive_link" target="_blank" rel="noopener noreferrer" className="bg-white rounded-xl shadow-lg overflow-hidden group hover:shadow-xl transition-shadow block">
              <img src="/Pad Thai.jpg" alt="Pad Thai - Main Menu" className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-amber-600 transition-colors">Main Menu</h3>
                <p className="text-gray-600">All Day Menu<br />Served Everyday</p>
              </div>
            </a>
            
            <a href="https://drive.google.com/file/d/1suTvZkeizpc1h_75IF38YjvEF-eD3wLu/view?usp=drive_link" target="_blank" rel="noopener noreferrer" className="bg-white rounded-xl shadow-lg overflow-hidden group hover:shadow-xl transition-shadow block">
              <img src="/Pad Thai Lunch.jpg" alt="Pad Thai Lunch - Lunch Specials" className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-amber-600 transition-colors">Lunch Specials</h3>
                <p className="text-gray-600">Monday to Thursday<br />11:30am - 3:00pm<br />(Holidays & Special Events may impact availability)</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      {/* Reservations Section */}
      <section id="reservations" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Make a Reservation</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-6">Reservation Information</h3>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <Sunset className="h-5 w-5 text-amber-600" />
                    <span className="text-orange-600 font-medium">Today's sunset: {getSunsetTime()}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-amber-600" />
                    <span className="text-gray-700">Reservations recommended for weekends and evenings</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Users className="h-5 w-5 text-amber-600" />
                    <span className="text-gray-700">Perfect for intimate dinners and group celebrations</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-amber-600" />
                    <span className="text-gray-700">Outdoor patio seating available with ocean views</span>
                  </div>
                </div>

                <div className="text-center">
                  <a 
                    href="tel:(310) 377-7200" 
                    className="bg-amber-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors shadow-lg inline-flex items-center gap-2"
                  >
                    <Phone className="h-5 w-5" />
                    Call to Reserve: (310) 377-7200
                  </a>
                  <div className="mt-4">
                    <a 
                      href="https://www.google.com/maps/reserve/v/dine/c/pTnf3PDiGGU?source=pa&opi=89978449&hl=en-US&gei=uQqBaPvbAee4kPIP8_jw4A4&sourceurl=https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dswan%2Bthai%2Brpv%26rlz%3D1C1RXQR_enUS1100US1100%26oq%3Dswan%2Bthai%2Brpv%26gs_lcrp%3DEgZjaHJvbWUyBggAEEUYOTIVCAEQLhgUGK8BGMcBGIcCGIAEGI4FMgwIAhAjGCcYgAQYigUyBggDEEUYQDIGCAQQIxgnMgYIBRBFGDwyBggGEEUYPTIGCAcQRRg90gEIMTUxMWowajeoAgCwAgA%26sourceid%3Dchrome%26ie%3DUTF-8&ihs=3" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-red-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors shadow-lg inline-flex items-center gap-2"
                    >
                      <Users className="h-5 w-5" />
                      Click to Reserve Online
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="/Screenshot_20221020_173033.jpg" 
                alt="Swan Thai Restaurant Outdoor Dining" 
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-xl"></div>
              <div className="absolute bottom-6 left-6 text-white">
                <h4 className="text-xl font-semibold mb-2">Sunset Dining Experience</h4>
                <p className="text-sm opacity-90">Enjoy breathtaking views while dining on our patio</p>
              </div>
            </div>
          </div>

            <div className="mt-8">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Reservation Policy</h3>
                <div className="space-y-2 text-gray-700">
                  <p>• 2 hours time limit for all diners</p>
                  <p>• 1.5 hours time limit for window seating</p>
                  <p>• Parties of 15 may require a credit card hold</p>
                  <p>• Parties of 20 or more should email us at Hello@SwanThaiRPV.com</p>
                  <p>• Attire: Niche casual, upper casual, or suit & tie for special occasions</p>
                </div>
              </div>
            </div>

        </div>
      </section>

      {/* Social Media Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Follow Us</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Stay connected with Swan Thai for the latest updates, special offers, and behind-the-scenes content
            </p>
          </div>

          <div className="flex justify-center">
            <a 
              href="https://www.instagram.com/swanthai.rpv/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center gap-3"
            >
              <Instagram className="h-6 w-6" />
              Follow @swanthai.rpv
              <ExternalLink className="h-4 w-4" />
            </a>
          </div>

          <div className="flex justify-center mt-6">
            <a 
              href="https://www.yelp.com/biz/swan-thai-rancho-palos-verdes" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-xl font-semibold hover:from-red-600 hover:to-red-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center gap-3"
            >
              <Star className="h-6 w-6" />
              Review us on Yelp
              <ExternalLink className="h-4 w-4" />
            </a>
          </div>

          <div className="mt-12 pt-8 border-t border-gray-200">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Download Our App</h3>
              <p className="text-gray-600">Order ahead and skip the wait</p>
            </div>
            <div className="flex justify-center mb-6">
              <img 
                src="/Swan Thai App logo.png" 
                alt="Swan Thai RPV App" 
                className="w-32 h-32 rounded-2xl shadow-lg"
              />
            </div>
            <div className="flex justify-center gap-4">
              <a 
                href="https://play.google.com/store/apps/details?id=com.chownow.swanthairpv" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-green-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 transition-all duration-300 shadow-lg hover:shadow-xl inline-flex items-center gap-2"
              >
                <Smartphone className="h-6 w-6" />
                Android App
                <ExternalLink className="h-4 w-4" />
              </a>
              <a 
                href="https://apps.apple.com/us/app/swan-thai-rpv/id6479296959" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-gray-900 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl inline-flex items-center gap-2"
              >
                <Smartphone className="h-6 w-6" />
                iOS App
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Careers/Employment Section */}
      <section id="careers" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Join Our Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Be part of a passionate team dedicated to culinary excellence and exceptional service
            </p>
            <div className="mt-8">
              <button 
                onClick={() => setShowJobApplication(true)}
                className="bg-amber-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors shadow-lg inline-flex items-center gap-2"
              >
                Apply Now
                <ExternalLink className="h-4 w-4" />
              </button>
            </div>
          </div>
          {jobOpenings.length > 0 ? (
            <div className="space-y-6">
              {jobOpenings.map((job, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">{job.title}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="bg-amber-100 text-amber-800 px-2 py-1 rounded">{job.type}</span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {job.location}
                        </span>
                      </div>
                    </div>
                    <button className="mt-4 md:mt-0 bg-amber-600 text-white px-6 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center gap-2">
                      Learn More
                    </button>
                  </div>
                  
                  <p className="text-gray-700 mb-4">{job.description}</p>
                </div>
              ))}
            </div>
          ) : (
            null
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Ready to experience Swan Thai? Get in touch with us today
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <a 
              href="https://www.google.com/maps/dir//31206+Palos+Verdes+Dr+W,+Rancho+Palos+Verdes,+CA+90275" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-center block hover:bg-gray-800 rounded-lg p-4 transition-colors duration-300 group"
            >
              <div className="bg-amber-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Location</h3>
              <div className="text-gray-300 group-hover:text-white transition-colors">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <span>31206 Palos Verdes Dr. West</span>
                  <MapPin className="h-4 w-4 opacity-70 group-hover:opacity-100 transition-opacity" />
                </div>
                Rancho Palos Verdes<br />CA 90275
              </div>
            </a>
            
            <div className="text-center">
              <div className="bg-amber-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Phone</h3>
              <p className="text-gray-300">(310) 377-7200<br />Reservations & Inquiries</p>
            </div>
            
            <div className="text-center">
              <div className="bg-amber-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Email</h3>
              <p className="text-gray-300">Hello@SwanThaiRPV.com</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <div className="text-center">
              <div className="bg-amber-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Hours</h3>
              <p className="text-gray-300">
                Sun - Thu: 11:30am to 9:00pm
                <br />Fri & Sat: 11:30am - 9:30pm
              </p>
            </div>
          </div>

          {/* Social Media Links */}
          <div className="mt-16 pt-8 border-t border-gray-700">
            <div className="flex justify-center space-x-6">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors">
                <Facebook className="h-8 w-8" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors">
                <Instagram className="h-8 w-8" />
              </a>
              <a href="https://www.yelp.com/biz/swan-thai-rancho-palos-verdes" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors">
                <Star className="h-8 w-8" />
              </a>
            </div>
            <p className="text-center text-gray-400 mt-8">
              © 2024 Swan Thai, RPV. All rights reserved.
            </p>
          </div>
        </div>
      </section>

      {/* Policies & Disclaimers Section */}
      <section id="policies" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Policies & Disclaimers</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Important information about our restaurant policies and terms
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Restaurant Policies</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Reservation Policy</h4>
                  <ul className="text-gray-700 space-y-1 text-sm">
                    <li>• 2 hours time limit for all diners</li>
                    <li>• 1.5 hours time limit for window seating</li>
                    <li>• Parties of 15 may require a credit card hold</li>
                    <li>• Parties of 20 or more should email us at Hello@SwanThaiRPV.com</li>
                    <li>• Attire: Niche casual, upper casual, or suit & tie for special occasions</li>
                    <li>• Late arrivals should call the restaurant. A 10 minutes grace period may be afforded upon Manager's discretion</li>
                    <li>• Cancelled reservations may be subject to a $10 fee per person</li>
                    <li>• Cancelled seats (showing up with less people than reserved) may be subject to a $10 fee per person</li>
                     <li>• Parties of 15 or more that do not have a credit card on hold may risk losing their reservation.</li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Dining Policy</h4>
                  <ul className="text-gray-700 space-y-1 text-sm">
                    <li>• 18% Gratuity charged for parties of 6 or more</li>
                    <li>• Outside food and beverages are not permitted</li>
                    <li>• Recommended attire: Niche casual, upper casual, or suit & tie for special occasions</li>
                    <li>• Smoking and vaping are strictly prohibited within 25 feet of the building, patio, or any dining areas. Guests who wish to smoke or vape must do so at a distance where smoke or vapor is no longer detectable to diners</li>
                    <li>• Children are welcome in our restaurant; however, they must be supervised by an adult at all times. For the comfort and enjoyment of all guests, we kindly ask that children remain seated and do not disrupt other diners' experiences.</li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Outside Food & Drink Policy</h4>
                  <p className="text-gray-700 text-sm mb-2">
                    Outside food & beverages are not permitted. However, contingent to Manager's discretion, the following items might accepted at an additional charge:
                  </p>
                  <ul className="text-gray-700 space-y-1 text-sm ml-4">
                    <li>• <strong>Outside Wines (750ml).</strong> Corkage fee equal to the cost of our House Wines</li>
                    <li>• <strong>Outside Cake or Dessert.</strong> A minimum charge of $4 per person. We may provide plates & utensils, but our staff is not responsible for cutting or storing items. If the server for any reason cuts or stores the item, the Restaurant is NOT responsible for damages.</li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Payment Policy</h4>
                  <ul className="text-gray-700 space-y-1 text-sm">
                    <li>• We accept cash, credit cards, and debit cards</li>
                    <li>• Gratuity is not included in the bill</li>
                    <li>• Split checks available up to 4</li>
                    <li>• No personal checks accepted</li>
                  </ul>
                </div>
              </div>
                <div className="mt-8">
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Pets</h4>
                  <ul className="text-gray-700 space-y-1 text-sm">
                    <li>• Pets are allowed only on the patio. Pets are not allowed inside the Restaurant—except for Service Animals—in full compliance with California Healthy & Safety Code §114259.5 and the ADA.</li>
                    <li>• Pets (including service animals) may be asked to leave if they are disruptive, uncontrolled, barking, roaming unsupervised, failing to keep off tables and chairs, or the owner fails to promptly clean urination or defecation.</li>
                    <li>• If it is not obvious that an animal is a Service Animal, staff may ask (1) "Is this a service animal required because of a disability?" and (2) "What work, or task, has the animal been trained to perform?"</li>
                  </ul>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Disclaimers</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Allergen Information</h4>
                  <p className="text-gray-700 text-sm mb-2">
                    Our kitchen handles common allergens including: milk, eggs, wheat, soybean, peanuts, tree nuts, fish, shellfish and gluten. While we take precautions, we cannot guarantee that any dish is completely free from allergens.
                  </p>
                  <p className="text-gray-700 text-sm">
                    Please inform your server of any allergies or dietary restrictions before ordering.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Spice Level Notice</h4>
                  <p className="text-gray-700 text-sm">
                    Thai cuisine traditionally uses various spice levels. Please specify your preferred spice level 
                    when ordering. We are not responsible for dishes that are too spicy for individual preferences.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Hours & Availability</h4>
                  <p className="text-gray-700 text-sm">
                    Operating hours and menu availability may change due to holidays, special events, or 
                    unforeseen circumstances. Please call ahead to confirm hours and availability.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Liability</h4>
                  <p className="text-gray-700 text-sm">
                    Swan Thai RPV is not responsible for lost, stolen, or damaged personal items. 
                    Customers dine at their own risk.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Menu</h4>
                  <p className="text-gray-700 text-sm">
                    Not all ingredients may be listed on the menu. Menu items and prices are subject to change without notice.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Warning Disclaimers */}
          <div className="mt-12 bg-yellow-50 border-l-4 border-yellow-400 rounded-lg p-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-semibold text-yellow-800 mb-4">Important Health & Safety Warnings</h3>
                <div className="space-y-4 text-sm text-yellow-700">
                  <div>
                    <h4 className="font-semibold mb-2">Prop 65 Warnings:</h4>
                    <p>Certain foods and beverages sold or served here can expose you to chemicals including acrylamide in many fried or baked goods, and mercury in fish, which is known to the State of California to cause cancer and birth defects or other reproductive harm. For more information go to <a href="https://www.P65Warnings.ca.gov/restaurant" target="_blank" rel="noopener noreferrer" className="text-yellow-800 underline hover:text-yellow-900">www.P65Warnings.ca.gov/restaurant</a>.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">Consumer Advisory:</h4>
                    <p>Consuming raw or undercooked meats, poultry, seafood, shellfish or eggs may increase the risk of a Foodborne Illness, particularly for those in vulnerable groups such as children & the elderly. Please be advised that food prepared here may contain these ingredients: milk, eggs, wheat, soybean, peanuts, tree nuts, fish and shellfish.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">Government Warning:</h4>
                    <p>(1) According to the Surgeon General, women should not drink alcoholic beverages during pregnancy because of the risk of birth defects. (2) Consumption of alcoholic beverages impairs your ability to drive a car or operate machinery and may cause health problems.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">Please drink responsibly:</h4>
                    <p>Must be at least 21 years of age to drink</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 bg-amber-50 border border-amber-200 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Contact Us</h3>
            <p className="text-gray-700 text-center">
              If you have any questions about our policies or need to discuss special accommodations, 
              please contact us at <a href="tel:(310) 377-7200" className="text-amber-600 hover:text-amber-700 font-medium">(310) 377-7200</a> 
              or email us at <a href="mailto:Hello@SwanThaiRPV.com" className="text-amber-600 hover:text-amber-700 font-medium">Hello@SwanThaiRPV.com</a>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;