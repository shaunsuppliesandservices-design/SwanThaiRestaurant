import React, { useState } from 'react';
import { ArrowLeft, Send, User, Mail, Phone, MapPin, Car, Clock, CheckCircle } from 'lucide-react';

interface AvailabilityDay {
  day: string;
  startTime: string;
  endTime: string;
  canStayUntilClose: boolean;
}

interface JobApplicationProps {
  onBack: () => void;
}

const JobApplication: React.FC<JobApplicationProps> = ({ onBack }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    cityZip: '',
    hasCar: '',
    hasVehicle: '',
    position: '',
    experience: '',
    whyWork: '',
    availability: [
      { day: 'Monday', startTime: '', endTime: '', canStayUntilClose: false },
      { day: 'Tuesday', startTime: '', endTime: '', canStayUntilClose: false },
      { day: 'Wednesday', startTime: '', endTime: '', canStayUntilClose: false },
      { day: 'Thursday', startTime: '', endTime: '', canStayUntilClose: false },
      { day: 'Friday', startTime: '', endTime: '', canStayUntilClose: false },
      { day: 'Saturday', startTime: '', endTime: '', canStayUntilClose: false },
      { day: 'Sunday', startTime: '', endTime: '', canStayUntilClose: false }
    ]
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAvailabilityChange = (dayIndex: number, field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      availability: prev.availability.map((day, index) => {
        if (index === dayIndex) {
          if (field === 'canStayUntilClose' && value === true) {
            return { ...day, [field]: value, endTime: 'Close' };
          } else if (field === 'canStayUntilClose' && value === false) {
            return { ...day, [field]: value, endTime: '' };
          }
          return { ...day, [field]: value };
        }
        return day;
      })
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Format availability for email
    const availabilityText = formData.availability
      .filter(day => day.startTime || day.endTime)
      .map(day => `${day.day}: ${day.startTime} - ${day.endTime}`)
      .join('\n');

    // Create email body
    const emailBody = `
Job Application - Swan Thai RPV

Personal Information:
Name: ${formData.firstName} ${formData.lastName}
Email: ${formData.email}
Phone: ${formData.phone}
City & Zip Code: ${formData.cityZip}

Transportation:
Do you drive? ${formData.hasCar}
Do you have your own vehicle? ${formData.hasVehicle}

Position Applied For: ${formData.position}

Experience: ${formData.experience}

Why do you want to work at Swan Thai? ${formData.whyWork}

Availability:
${availabilityText}
    `.trim();

    // Create mailto link
    const mailtoLink = `mailto:Hello@SwanThaiRPV.com?subject=Job Application - ${formData.firstName} ${formData.lastName}&body=${encodeURIComponent(emailBody)}`;
    
    // Open email client
    window.location.href = mailtoLink;
    
    // Simulate submission delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1000);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Application Sent!</h2>
            <p className="text-gray-600 mb-6">
              Your job application has been prepared and your email client should have opened. 
              Please send the email to complete your application.
            </p>
            <button
              onClick={onBack}
              className="bg-amber-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors"
            >
              Back to Careers
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium mb-4"
          >
            <ArrowLeft className="h-5 w-5" />
            Back to Careers
          </button>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Join Our Team</h1>
          <p className="text-xl text-gray-600">Apply for a position at Swan Thai RPV</p>
        </div>

        {/* Application Form */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Personal Information */}
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <User className="h-5 w-5 text-amber-600" />
                Personal Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    First Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Last Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  City & Zip Code *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Rancho Palos Verdes, CA 90275"
                  value={formData.cityZip}
                  onChange={(e) => handleInputChange('cityZip', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                />
              </div>
            </div>

            {/* Transportation */}
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Car className="h-5 w-5 text-amber-600" />
                Transportation
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Do you drive? *
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="hasCar"
                        value="Yes"
                        checked={formData.hasCar === 'Yes'}
                        onChange={(e) => handleInputChange('hasCar', e.target.value)}
                        className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300"
                        required
                      />
                      <span className="ml-2 text-gray-700">Yes</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="hasCar"
                        value="No"
                        checked={formData.hasCar === 'No'}
                        onChange={(e) => handleInputChange('hasCar', e.target.value)}
                        className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300"
                        required
                      />
                      <span className="ml-2 text-gray-700">No</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Do you have your own vehicle? *
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="hasVehicle"
                        value="Yes"
                        checked={formData.hasVehicle === 'Yes'}
                        onChange={(e) => handleInputChange('hasVehicle', e.target.value)}
                        className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300"
                        required
                      />
                      <span className="ml-2 text-gray-700">Yes</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="hasVehicle"
                        value="No"
                        checked={formData.hasVehicle === 'No'}
                        onChange={(e) => handleInputChange('hasVehicle', e.target.value)}
                        className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300"
                        required
                      />
                      <span className="ml-2 text-gray-700">No</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Position and Experience */}
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Position & Experience</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    What position are you applying for? *
                  </label>
                  <select
                    required
                    value={formData.position}
                    onChange={(e) => handleInputChange('position', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  >
                    <option value="">Select a position</option>
                    <option value="Server">Dishwasher</option>
                    <option value="Host/Hostess">Host/Hostess</option>
                    <option value="Kitchen Staff">Busser</option>
                    <option value="Bartender">Food Runner</option>
                    <option value="Busser">Server</option>
                    <option value="Manager">Bartender</option>
                    <option value="Other">Chef</option>
                    <option value="Other">Prep</option>
                    <option value="Other">Supervisor</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tell us about your relevant experience *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={formData.experience}
                    onChange={(e) => handleInputChange('experience', e.target.value)}
                    placeholder="Describe your work experience, especially in restaurants or customer service..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Why do you want to work at Swan Thai? *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={formData.whyWork}
                    onChange={(e) => handleInputChange('whyWork', e.target.value)}
                    placeholder="Tell us what interests you about working at our restaurant..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
              </div>
            </div>

            {/* Availability */}
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-600" />
                Availability
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Please indicate your availability for each day of the week
              </p>
              <div className="space-y-4">
                {formData.availability.map((day, index) => (
                  <div key={day.day} className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                      <div className="font-medium text-gray-900">
                        {day.day}
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-600 mb-1">
                          Start Time
                        </label>
                        <input
                          type="time"
                          value={day.startTime}
                          onChange={(e) => handleAvailabilityChange(index, 'startTime', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-600 mb-1">
                          End Time
                        </label>
                        <input
                          type="time"
                          value={day.canStayUntilClose ? '' : day.endTime}
                          onChange={(e) => handleAvailabilityChange(index, 'endTime', e.target.value)}
                          disabled={day.canStayUntilClose}
                          placeholder={day.canStayUntilClose ? 'Close' : ''}
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-amber-500 focus:border-amber-500 disabled:bg-gray-100 disabled:text-gray-500"
                        />
                        {day.canStayUntilClose && (
                          <div className="text-sm text-amber-600 mt-1">Close</div>
                        )}
                      </div>
                      
                      <div>
                        <label className="flex items-center text-sm">
                          <input
                            type="checkbox"
                            checked={day.canStayUntilClose}
                            onChange={(e) => handleAvailabilityChange(index, 'canStayUntilClose', e.target.checked)}
                            className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                          />
                          <span className="ml-2 text-gray-700">Can stay until close</span>
                        </label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-6 border-t border-gray-200">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-amber-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-amber-700 transition-colors shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    Preparing Application...
                  </>
                ) : (
                  <>
                    <Send className="h-5 w-5" />
                    Submit Application
                  </>
                )}
              </button>
              <p className="text-sm text-gray-500 text-center mt-2">
                This will open your email client to send your application to Swan Thai RPV
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default JobApplication;